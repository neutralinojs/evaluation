"Hello world" in node-webkit
